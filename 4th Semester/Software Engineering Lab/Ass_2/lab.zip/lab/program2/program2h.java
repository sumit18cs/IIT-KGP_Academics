import java.util.Scanner;
class program2h
{
	static boolean prime(int n, int i) 
	{ 
	    if (n <= 2) 
	        return (n == 2) ? true : false; 
	    if (n % i == 0) 
	        return false; 
	    if (i * i > n) 
	        return true; 
	  
	    return prime(n, i + 1); 
	} 
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		System.out.println("enter number");
		int a=in.nextInt();
		System.out.println(prime(a,2));
	}
}
