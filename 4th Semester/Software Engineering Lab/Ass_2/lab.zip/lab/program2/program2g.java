// Java program to print all combination of size r in an array of size n 
import java.io.*; 
import java.util.Scanner;
class program2g
{ 
	static void comb(int arr[], int data[], int start, int end, int index, int r) 
	{ 
			if (index == r) 
		{ 
			for (int j=0; j<r; j++) 
				System.out.print(data[j]+" "); 
			System.out.println(""); 
			return; 
		} 
		for (int i=start; i<=end && end-i+1 >= r-index; i++) 
		{ 
			data[index] = arr[i]; 
			comb(arr, data, i+1, end, index+1, r); 
		} 
	} 
	static void print(int arr[], int n, int r) 
	{ 
		int data[]=new int[r]; 

		comb(arr, data, 0, n-1, 0, r); 
	} 

	public static void main (String[] args) 
	{ 
		Scanner in = new Scanner(System.in); 
        System.out.println("enter value of n");
        int n=in.nextInt();
		int arr[]=new int [n];
		for(int i=0;i<n;i++)
		{
			arr[i]=i;
		}
		System.out.println("enter value of r");
		int r=in.nextInt();
		print(arr, n, r); 
	} 
} 