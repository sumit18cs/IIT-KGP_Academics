import java.util.Scanner;
class program2a
{
	static int fact(int n)
	{
		if(n<=1)
		{
			return 1;
		}
		return n*fact(n-1);
	}
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		System.out.println("enter number");
		int a=in.nextInt();
		System.out.println(fact(a));
	}
}