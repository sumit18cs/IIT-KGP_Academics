import java.util.Scanner;
class program2b
{
	static int fib(int n)
	{
		if(n<=2)
		{
			return 1;
		}
		return fib(n-1)+fib(n-2);
	}
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		System.out.println("enter number");
		int a=in.nextInt();
		System.out.println(fib(a));
	}
}