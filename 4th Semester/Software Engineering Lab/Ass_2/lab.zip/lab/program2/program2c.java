import java.util.Scanner;
class program2c
{
	static int fib( int testedNumber, int a, int b)
		{
		    if( testedNumber == 0 || testedNumber == 1 )
		        return 1;
		    int nextFib = a + b;
		    if( nextFib > testedNumber )
		        return 0;
		    else if( nextFib == testedNumber )
		        return 1;
		    else
		        return fib( testedNumber, b, nextFib );
		}
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		System.out.println("enter number");
		int a=in.nextInt();
		int b=fib(a,1,1);
		if(b ==1)
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");
		}
		
	}

}