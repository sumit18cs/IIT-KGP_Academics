package test;
import java.util.Scanner;
import point.*;
import circle.*;
public class test
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		int n=in.nextInt();
		
		double x[][]=new double [n][3];
		double radius;
		int i;
		for(i=0;i<n;i++)
		{	
			circle c=new circle();
			radius=Math.sqrt((c.x-c.x1)*(c.x-c.x1)+(c.y-c.y1)*(c.y-c.y1));
			x[i][0]=c.x;
			x[i][1]=c.y;
			x[i][2]=radius;
		}
		for(i=0;i<n;i++)
		{
			System.out.print("circle :"+(i+1)+"  centre coordinate(x,y): "+x[i][0]+" , "+x[i][1]+"  "+"radius: "+x[i][2]+"\n");
		}
		int j;
		for(i=0;i<n-1;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(Math.sqrt((x[i][0]*x[j][0])+(x[i][1]*x[j][1]))+x[i][2]<=x[j][2])
				{
					System.out.println("circle: "+(i+1)+" is inside the circle "+(j+1));
				}
			}
		}
	}
	
}