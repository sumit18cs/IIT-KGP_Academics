package circle;
import point.point;
public class circle extends point
{
	public double x1,y1;
	public circle()
	{
		this.x1=Math.random();
		this.y1=Math.random();
		this.x1=200*x1-100;
		this.y1=200*y1-100;
	}
}