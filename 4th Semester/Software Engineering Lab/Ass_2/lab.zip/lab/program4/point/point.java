package point;
public class point
{
	public double x,y;
	public point()
	{
		this.x=Math.random();
		this.y=Math.random();
		this.x=200*x-100;  //to ensure that x and y in the range -100<to<100 as random fn gives in range [0,1).
		this.y=200*y-100;
	}
}