import java.io.*; 
class program1c 
{ 
   public static void main(String args[]) throws IOException 
   { 
      //writing the data. 
      try ( DataOutputStream dout =new DataOutputStream(new FileOutputStream("file.txt")) ) 
      { 
         dout.writeInt(43); 
         dout.writeInt(12); 
         dout.writeInt(76);  
      } 
      
      catch(FileNotFoundException ex) 
      { 
         System.out.println("Cannot Open the Output File"); 
         return; 
      } 
      
      // reading the data back. 
      try ( DataInputStream din =new DataInputStream(new FileInputStream("file.txt")) ) 
      { 
         int a = din.readInt(); 
         int b = din.readInt(); 
         int c = din.readInt(); 
         if(a>=b && a>=c)
         {
            System.out.println(a);
         }
         else if(b>=a && b>=c)
         {
            System.out.println(b);
         }
         else
         {
            System.out.println(c);
         }
      } 
      catch(FileNotFoundException e) 
      { 
         System.out.println("Cannot Open the Input File"); 
         return; 
      } 
   } 
} 
