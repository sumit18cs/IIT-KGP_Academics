import java.util.Scanner;
class person
{
	int id;
	String mob;
	public void readdata()
	{
		Scanner in = new Scanner(System.in); 
		System.out.println("enter id and mobile no.");
		id=in.nextInt();
		mob=in.nextLine(); //to avoid buffer.
		mob=in.nextLine();
	}
	public void printdata()
	{
		System.out.println("ID : "+id+"\nmobile no. : "+mob);
	}
}
class student extends person
{
	String category;
	int rollno;
	String department;
	int marks[]=new int [12];
	int n,i;
	public void readdata()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter category"); 
		category=in.nextLine();
		System.out.println("enter roll no."); 
		rollno=in.nextInt();
		System.out.println("enter department");
		department=in.nextLine();
		System.out.println("enter no. of student");
		n=in.nextInt();
		System.out.println("enter marks of each student");
		for(i=0;i<n;i++)
		{
			marks[i]=in.nextInt();
		}   
	}
	public void printdata()
	{
		System.out.println("student information:\ncategory: "+category+"\nroll no: "+rollno+"\ndepartment: "+department);
		for(i=0;i<n;i++)
		{
			System.out.print(marks[i]+" ");
		} 
	}
} 
class employee extends person
{
	int employeecode;
	int salary;
	String designation;
	int doj;
	public void readdata()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter employeecode"); 
		employeecode=in.nextInt();
		System.out.println("enter salary"); 
		salary=in.nextInt();
		System.out.println("enter designation"); 
		designation=in.nextLine();
		System.out.println("enter doj"); 
		doj=in.nextInt();
	}
	public void printdata()
	{
		System.out.println("\nemployeecode: "+employeecode+"\nsalary: "+salary+"\ndesignation: "+designation+"\ndoj: "+doj); 
	}
}
class pg extends student
{
	String project,supervisor;
	public void readdata()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter project name");
		project=in.nextLine();
		System.out.println("enter supervisor name");
		supervisor=in.nextLine();  
	}
	public void printdata()
	{
		System.out.println("project name: "+project+"\nsupervisor name: "+supervisor);
	}
}
class phd extends student
{
	String thesis,department,area;
	int pub[]=new int[12];
	int n,i;
	public void readdata()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter thesis");
		thesis=in.nextLine();
		System.out.println("enter department");
		department=in.nextLine();
		System.out.println("enter area");
		area=in.nextLine();
		System.out.println("enter no. of publication");
		n=in.nextInt();
		System.out.println("enter publication year"); 
		for(i=0;i<n;i++)
		{
			pub[i]=in.nextInt();
		} 

	}
	public void printdata()
	{
		System.out.println("thesis: "+thesis+"\ndepartment: "+department+"\narea"+area);
		for(i=0;i<n;i++)
		{
			System.out.print(pub[i]+" ");
		}
	}
}
class program5
{
	public static void main(String args[])
	{
		int i;
		student s=new student();
		employee e=new employee();
		person p[]=new person[10];
		for(i=0;i<10;i++)
		{
			p[i]=new person();
			p[i].readdata();
			p[i].printdata();
		}
	}
}