class program2
{
	public static int j;
	public static void main (String args[ ] ) 
	{
		for (int i = 0; i < 4; i++ ) 
		{
			switch (i) 
				{
						case 0 :
							try
							{
								int zero = 0;
								j = 999/ zero; // Divide by zero
							}
							catch(ArithmeticException e)
							{
								System.out.println("warning:number is divisible by zero");
							}
							catch(Exception e4)
							{
								System.out.println("warning:exception occured");
							}
							break;
						case 1:
							try
							{
								int b[ ] = null;
								j = b[0] ; // Null pointer error
							}
							catch(NullPointerException e1)
							{
								System.out.println("warning:null pointer error");
							}
							catch(Exception e4)
							{
								System.out.println("warning:exception occured");
							}
							break;
						case 2:
							try
							{
								int c[] = new int [2] ;
								j = c[10]; // Array index is out-of-bound		
							}
							catch(ArrayIndexOutOfBoundsException e2)
							{
								System.out.println("warning:ArrayIndexOutOfBoundsException");
							}
							catch(Exception e4)
							{
								System.out.println("warning:exception occured");
							}
							break;
						case 3:
							try
							{
								char ch = "Java".charAt(9) ;// String index is out-of-bound
							}
							catch(ArrayIndexOutOfBoundsException e2)
							{
								System.out.println("warning:ArrayIndexOutOfBoundsException");
							}
							catch(Exception e4)
							{
								System.out.println("warning:exception occured");
							}
							break;
				}
		}
	}
}