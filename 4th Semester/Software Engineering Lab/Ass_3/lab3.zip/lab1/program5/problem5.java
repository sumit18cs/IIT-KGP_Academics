import java.util.Scanner; // Import the Scanner class to read text files
import java.io.*;

class Student implements Serializable{
	String Name ;
	String Roll;
	String Department;
	public Student(String name,String roll,String Department){
		this.Name = name ;
		this.Roll = roll;
		this.Department=Department;
	}
	public void printData(){
		System.out.println("Name :"+Name+"\nRollNo:"+Roll+"\nDepartment:"+Department);
	}

}
public class problem5{
	public static void main(String[] args) {
	 try{
	      File myObj = new File("filename.txt");
	      if (myObj.createNewFile()) {
	        System.out.println("File created: " + myObj.getName() + "\n Give input: \n");
	      } else {
	        System.out.println("File already exists.");
	      }
	    }
	    catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
		String inputText;
		Scanner in = new Scanner(System.in);
		inputText = in.nextLine();
	  try{
	      FileWriter myWriter = new FileWriter("filename.txt");
	      myWriter.write(inputText);
	      myWriter.close();
	      System.out.println("Successfully wrote to the file.");
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }

      	//copying filename.txt to file.txt 
      	try{
	      	File myObj = new File("file.txt");
	     	if (myObj.createNewFile()) {
	        System.out.println("File created: " + myObj.getName() + "\n Give input: \n");
	      	} else {
	       	 System.out.println("File already exists.");
	      	}
	    }
	    catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }

    FileInputStream instream = null;
	FileOutputStream outstream = null;
 
    try{
    	    File infile =new File("filename.txt");
    	    File outfile =new File("file.txt");
    	    instream = new FileInputStream(infile);
    	    outstream = new FileOutputStream(outfile);
    	    byte[] buffer = new byte[1024];
    	    int length;
    	    /*copying the contents from input stream to
    	     * output stream using read and write methods
    	     */
    	    while ((length = instream.read(buffer)) > 0){
    	    	outstream.write(buffer, 0, length);
    	    }
    	    //Closing the input/output file streams
    	    instream.close();
    	    outstream.close();
    	    System.out.println("File copied successfully!!");
 
    	}catch(IOException ioe){
    		ioe.printStackTrace();
    	}
    	Student [] students = new Student[10];
    	String name ;
		String roll;
		String dept;
    	System.out.println("Give Details of 10 Students:");
    	for(int i=1;i<=10;i++){
    		   System.out.println("Give Name , RollNo & Department:");
    		   name = in.nextLine();
    		   roll = in.nextLine();
    		   dept = in.nextLine();
    		   Student s1 = new Student(name,roll,dept);
    		   students[i-1]=s1;
    	}
    	for(int i=0;i<10;i++){
				// Write objects to file
    		try{
    			 	FileOutputStream f = new FileOutputStream(new File("myObjects.txt"));
    				ObjectOutputStream o = new ObjectOutputStream(f);
    				o.writeObject(students[i]);
	
    		}
			catch(Exception e){
				System.out.println(e);
			}
    	}
    	for(int i=0;i<10;i++){
    		try{
    		FileInputStream fi = fi = new FileInputStream(new File("myObjects.txt"));

    		ObjectInputStream oi = oi = new ObjectInputStream(fi);

			Student s1 = (Student)oi.readObject();
			System.out.println(s1.toString());
		}catch(Exception e){
			System.out.println(e);
		}

    	}
	}
}