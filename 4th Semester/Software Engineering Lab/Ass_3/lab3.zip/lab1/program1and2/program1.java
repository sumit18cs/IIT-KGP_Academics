class program1 
{
	public static void main (String args [ ]) 
	{
		
		//System.out.println("hello"+c);
		try
		{
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
			int c = a/b;
			System.out.println("value of c is "+c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("you should not divide a number by zero");
		}
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.println("warning:ArrayIndexOutOfBoundsException");
		}
		catch(NumberFormatException e3)
		{
			System.out.println("warning:number format exception");
		}
		catch(Exception e2)
		{
			System.out.println("some other exception");
		}
		
	}
}