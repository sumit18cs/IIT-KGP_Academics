package MyPackage2;
public class B {
// class with default protection
public B() {
// default constructor with default access
MyPackage1.X x = new MyPackage1.X();
// create an object of class X
System.out.println("I am constructor from class B of MyPackage2");
System.out.println("n from B of myPackage2"+x.n);
//default variable but is not accessible in this package
System.out.println("p from B of myPackage2"+x.p);
// Error
System.out.println("q from B of myPackage2"+x.q);
// Error protection
System.out.println("r from A of myPackage2"+x.r);
}
}