package demo;
import MyPackage2.*;
public class demo2
{
	public static void main(String args[])
	{
		Z z2=new Z();
		B b2=new B();
	}
}