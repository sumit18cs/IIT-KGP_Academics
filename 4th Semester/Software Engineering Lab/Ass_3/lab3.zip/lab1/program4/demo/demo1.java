package demo; 
import MyPackage1.*;
import MyPackage2.*;
public class demo1
{
	public static void main(String args[])
	{
		X x1=new X();
		Y y1=new Y();
		A a1=new A();
	}
}