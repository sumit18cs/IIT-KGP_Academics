class program2
{
	public static void main(String args[])
	{
		int i;
		System.out.println("First 10 natural number");
		for(i=1;i<11;i++)
		{
			System.out.print(i+"  ");
		}
	}
}