import java.util.Scanner;
class program6
{
	public static void main(String args[])
	{
		int i,j,k;
		System.out.println("enter no. of rows in 3d matrix");
		Scanner in = new Scanner(System.in); 
		int n=in.nextInt();
		int x[][][]=new int[n][n][n]; 
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				for(k=0;k<n;k++)
				{
					x[i][j][k]=i*j*k;
				}
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				for(k=0;k<n;k++)
				{
					System.out.print(x[i][j][k]+"  ");
				}
				System.out.print("\n");
			}
			System.out.print("\n");
		}
	}
}