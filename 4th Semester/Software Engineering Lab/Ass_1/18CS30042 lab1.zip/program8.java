import java.util.Scanner;
class program8
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		double r=in.nextDouble();
		double x=in.nextDouble();//y coordinate of centre
		double y=in.nextDouble();//x coordinate of centre
		System.out.println("input coordinate of point");
		double x1=in.nextDouble();
		double y1=in.nextDouble();
		if((x-x1)*(x-x1)+(y-y1)*(y-y1)>(r*r))
		{
			System.out.println("point is outside the circle");
		}
		else
		{
			System.out.println("point is inside the circle");
		}
	}
}