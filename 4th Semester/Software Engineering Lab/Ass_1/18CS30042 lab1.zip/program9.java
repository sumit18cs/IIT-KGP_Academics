import java.util.Scanner;
class program9
{
	public static void main(String args[])
	{
		int i,n;
		Scanner in = new Scanner(System.in); 
		n=in.nextInt();
		int x[]=new int[n+1];
		x[0]=1;
		for(i=1;i<=n;i++)
		{
			x[i]=x[i-1]*i;
		}
		System.out.println("factorial of given number :"+x[n]);
	}
}