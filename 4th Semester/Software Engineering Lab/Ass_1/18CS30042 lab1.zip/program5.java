import java.util.Scanner;
class program5
{
	public static void main(String args[])
	{
		Scanner in = new Scanner(System.in); 
		int i,j;
		System.out.println("enter no. of rows");
		int n=in.nextInt();
		System.out.println("enter the element of matrix");
		int x[][]=new int[n][n];
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				x[i][j]=in.nextInt();
			}
		}
		System.out.println("the given matrix is:");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print(x[i][j]+" ");
			}
			System.out.print("\n");
		}
	}
}