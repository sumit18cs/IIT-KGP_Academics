class program4
{
	public static void main(String args[])
	{
		int i;
		float sum;
		int n=12;
		int x[]=new int[n]; 
		for(i=1;i<=10;i++)
		{
			x[i]=i;
		}
		sum=0;
		for(i=1;i<=10;i++)
		{
			sum=sum+x[i];
		}
		sum=sum/10;
		System.out.println("average of first 10 natural number:"+sum);
	}
}