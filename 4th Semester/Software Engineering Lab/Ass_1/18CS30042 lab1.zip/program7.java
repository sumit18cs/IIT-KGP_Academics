import java.util.Scanner;
class program7
{
	public static void main(String args[])
	{
		double ar,cir;
		Scanner in = new Scanner(System.in); 
		double r=in.nextDouble();
		ar=3.14*r*r;
		cir=2*3.14*r;
		System.out.println("area of circle :"+ar+"\n"+"circumference of circle :"+cir);
	}
}