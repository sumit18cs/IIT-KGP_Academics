import java.io.*;
import java.util.Scanner; 
public  class Student{
		String RollNo;;
		String Name ;
		String Department ;
		public void printData()
		{
			System.out.print(RollNo + " \n" +Name +" \n"+ Department);
		}
		Student(String name , String roll , String dept){
			Name = name ;
			RollNo = roll ;
			Department = dept ;

		}
		public static void main(String[] args) 
		{
		Student [] students = new Student[10];
		String name,roll,dept ;
		Scanner in = new Scanner(System.in);   
		for(int i=0;i<1;i++)
		{
			System.out.print("Enter details Name ,RollNo and Department");
			String s=in.nextLine();   
			name = in.nextLine();
			roll = in.nextLine();
			dept = in.nextLine();
			students[i] = new Student(name,roll,dept);
		}
	}
}
