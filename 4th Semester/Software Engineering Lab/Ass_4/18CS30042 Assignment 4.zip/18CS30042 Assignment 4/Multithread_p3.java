import java.util.concurrent.ThreadLocalRandom;
class BubleSort extends Thread { 

	public void run(int arr[]) 
	{ 
	    int n = arr.length;  
        int temp = 0;  
        for(int i=0; i < n; i++){  
                for(int j=1; j < (n-i); j++){  
                         if(arr[j-1] > arr[j]){  
                                 //swap elements  
                                temp = arr[j-1];  
                                arr[j-1] = arr[j];  
                                arr[j] = temp;  
                        }  
                          
                }  
        }
	} 
} 
class MergeSort extends Thread { 
    
    void merge(int arr[], int l, int m, int r) 
    { 
        int n1 = m - l + 1; 
        int n2 = r - m; 
  
        int L[] = new int [n1]; 
        int R[] = new int [n2]; 
  
        for (int i=0; i<n1; ++i) 
            L[i] = arr[l + i]; 
        for (int j=0; j<n2; ++j) 
            R[j] = arr[m + 1+ j]; 
  
  

        int i = 0, j = 0; 
  
        int k = l; 
        while (i < n1 && j < n2) 
        { 
            if (L[i] <= R[j]) 
            { 
                arr[k] = L[i]; 
                i++; 
            } 
            else
            { 
                arr[k] = R[j]; 
                j++; 
            } 
            k++; 
        } 
  
        while (i < n1) 
        { 
            arr[k] = L[i]; 
            i++; 
            k++; 
        } 
        while (j < n2) 
        { 
            arr[k] = R[j]; 
            j++; 
            k++; 
        } 
    } 
    
    void sort(int arr[], int l, int r) 
    { 
        if (l < r) 
        { 
            int m = (l+r)/2; 
  
            sort(arr, l, m); 
            sort(arr , m+1, r); 
            merge(arr, l, m, r); 
        } 
    } 

	public void run(int arr[]) 
	{ 
        int n = arr.length;
        sort(arr,0,n-1);
	}
	
}

class quick_sort extends Thread { 
    
    int partition(int arr[], int low, int high) 
    { 
        int pivot = arr[high];  
        int i = (low-1);
        for (int j=low; j<high; j++) 
        { 
            if (arr[j] < pivot) 
            { 
                i++; 
                int temp = arr[i]; 
                arr[i] = arr[j]; 
                arr[j] = temp; 
            } 
        } 
        int temp = arr[i+1]; 
        arr[i+1] = arr[high]; 
        arr[high] = temp; 
  
        return i+1; 
    } 
  
    void sort(int arr[], int low, int high) 
    { 
        if (low < high) 
        { 
            int pi = partition(arr, low, high); 
            sort(arr, low, pi-1); 
            sort(arr, pi+1, high); 
        } 
    } 

	public void run(int arr[]) 
	{ 
        int n = arr.length;
        sort(arr,0,n-1);
	}
	
}

class BinarySearchExample{  
  
}

public class Multithread_p3 {
    
    int  binarySearch(int arr[], int l, int r, int x) 
    { 
        if (r >= l) { 
            int mid = l + (r - l) / 2; 
  
            if (arr[mid] == x) 
                return mid; 
  
 
            if (arr[mid] > x) 
                return binarySearch(arr, l, mid - 1, x); 
            return binarySearch(arr, mid + 1, r, x); 
        } 

        return -1; 
    } 
    public static void main(String args[]) {
		int arr[] = new int[50];
		System.out.println("Initial Array is:");
      	for(int i=0;i<50;i++)
      	{
          int randomNum = ThreadLocalRandom.current().nextInt(1, 99 + 1);
          arr[i] = randomNum;
          System.out.print(arr[i] + " ");
          if(i==49){
            System.out.print("\n");
          }
        }
        
        //Run  sorts by removing commenting part
        
        //BubleSort ob = new BubleSort();
        //MergeSort ob = new MergeSort();
        quick_sort ob = new quick_sort();
        ob.run(arr);
        
        System.out.println("After  Sorting :");
        for(int i=0;i<50;i++){
            System.out.print(arr[i] + " ");
        }
        
        int randomNum = ThreadLocalRandom.current().nextInt(0, 49 + 1);
        int key = arr[randomNum];
        System.out.println("\nAfter applying Binary Search of Random number "+ key);
        Multithread_p3 ob1 = new Multithread_p3(); 
        int x = ob1.binarySearch(arr,0,49,key);
        if(x==-1)System.out.println("NOT FOUND");
        else System.out.println("FOUND Index: "+ x);
        
        
    }
}
