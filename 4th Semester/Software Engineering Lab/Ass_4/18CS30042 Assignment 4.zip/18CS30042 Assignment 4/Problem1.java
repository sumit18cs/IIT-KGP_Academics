import java.io.*; 
import java.util.Scanner; 
public class Problem1 {  
	public static void main(String args[]){    
		try
		{   
			System.out.println("Write something into the file...");     
			FileOutputStream fout=new FileOutputStream("text.txt");  
			Scanner in = new Scanner(System.in);   
			String s=in.nextLine();    
			byte b[]=s.getBytes();   
			fout.write(b);    
			fout.close();    
			System.out.println("File writing is over...");    
		}
		catch(Exception e)
		{
			System.out.println(e);
		}    
	}    
}
