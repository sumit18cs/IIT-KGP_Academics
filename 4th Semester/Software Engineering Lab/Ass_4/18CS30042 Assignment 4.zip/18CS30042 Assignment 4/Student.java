import java.io.*;

public class Student{
	String Name;
	String Course;
	int rollNO;

	public Student(String Name, String Course, int rollNO){
		this.Name = Name;
		this.Course = Course;
		this.rollNO = rollNO;
	}

	public static void main(String[] args) {

	    Student myObj1 = new Student("John","Maths",19);  
	    Student myObj2 = new Student("Alan","Science",48);
	    Student myObj3 = new Student("Kelly","Arts",27);  
	    Student myObj4 = new Student("Austin","Social Studies",52);
	    Student myObj5 = new Student("Dorothy","Computer Studies",29);  
	    Student myObj6 = new Student("Becky","Science",56);
	    Student myObj7 = new Student("Peter","Arts",12);  
	    Student myObj8 = new Student("Karen","Maths",37);
	    Student myObj9 = new Student("Anthony","Maths",67); 
	    Student myObj10 = new Student("Julia","Computer Studies",49);  
	    
	    RandomAccessFile file = null;
	    
	    try {
	        
	        file = new RandomAccessFile("rand.dat","rw");
	        
	        file.writeChars(myObj1.Name+"\n");
	        file.writeChars(myObj1.Course+"\n");
	        file.writeInt(myObj1.rollNO);
	        
	        file.writeChars(myObj2.Name+"\n");
	        file.writeChars(myObj2.Course+"\n");
	        file.writeInt(myObj2.rollNO);
	        
	        file.writeChars(myObj3.Name+"\n");
	        file.writeChars(myObj3.Course+"\n");
	        file.writeInt(myObj3.rollNO);
	        
	        file.writeChars(myObj4.Name+"\n");
	        file.writeChars(myObj4.Course+"\n");
	        file.writeInt(myObj4.rollNO);
	        
	        file.writeChars(myObj5.Name+"\n");
	        file.writeChars(myObj5.Course+"\n");
	        file.writeInt(myObj5.rollNO);
	        
	        file.writeChars(myObj6.Name+"\n");
	        file.writeChars(myObj6.Course+"\n");
	        file.writeInt(myObj6.rollNO);
	        
	        file.writeChars(myObj7.Name+"\n");
	        file.writeChars(myObj7.Course+"\n");
	        file.writeInt(myObj7.rollNO);
	        
	        file.writeChars(myObj8.Name+"\n");
	        file.writeChars(myObj8.Course+"\n");
	        file.writeInt(myObj8.rollNO);
	        
	        file.writeChars(myObj9.Name+"\n");
	        file.writeChars(myObj9.Course+"\n");
	        file.writeInt(myObj9.rollNO);
	        	        
	        file.writeChars(myObj10.Name+"\n");
	        file.writeChars(myObj10.Course+"\n");
	        file.writeInt(myObj10.rollNO);
    	    file.seek(0);
    	    
    	    for(int i=0; i<10; ++i){
    	        System.out.println(file.readLine());
    	        System.out.println(file.readLine());
    	        System.out.println(file.readInt());
    	    }
    	    
	    } catch(Exception e) {
	        System.out.println(e);
	    }
	   
  	}

}

