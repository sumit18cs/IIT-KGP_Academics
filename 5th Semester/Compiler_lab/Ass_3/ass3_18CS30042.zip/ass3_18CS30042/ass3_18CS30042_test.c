//Name: Sumit Kumar Yadav
//Roll No.: 18CS30042


#include<stdio.h>
void introduction()
{
	char[20] name="Sumit Kumar Yadav";
	char[20] roll_no.="18CS30042";
	printf("%c\n",name);
}
int factorial(int n)
{
	int p=1;
	for(i=2;i<=n;i++)
	{
		p=p*i;
	}
	return p;
}
int main()
{
	//Testing keyword
	break, float, static, case, for, struct, char, goto, switch, continue, if, typedef;
	default, int, union, do, long, void, double, return, while, else, short, extern, sizeof;

	//Testing Identifier
	Indian Institute of Technology, Kharagpur
	a b c d e f g h i j k l m n o p q r s t u v v x y z
	A B C D E F G H I J K L M N O P Q R S T U V W X Y z
	0 1 2 3 4 5 6 7 8 9

	//Testing constants
	extern unsigned int a=0;
	static short b=0;
	double d=234.7835;
	int c=-2312;
	c=32e+3;
	int e=sizeof(char);
	char c='a','b';
	c="assignment_3";
	\' \'' \? \\ \a \b \f \n \r \t \v
	long s=0;
	for(int i=2;i<=5;i++)
	{
		s=s+i;
	}	
	//Testing punctuator
	[ ] ( ) { } . ->
	++ -- & * + - ~ !
	/ % << >> < > <= >= == != ^ | && ||
	? : ; ...
	= *= /= %= += -= <<= >>= &= ^= |=
	, #

	//Testing comments
	//Above one is alrady a single line comment
	/* write anything here is not going to display on output */
	/**abc**/ 
	
}