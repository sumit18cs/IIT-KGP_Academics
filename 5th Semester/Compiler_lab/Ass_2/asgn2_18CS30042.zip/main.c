//Name : Sumit kumar Yadav
//Roll No.: 18CS30042

#include "toylib.h"
int main()
{
	int n,hexint;
	float f;
	printStringUpper("Info:\n1. All the print statement are printed using the printStringUpper function\n2. Please enter Hexadecimal integer in such a way that its value in decimal form must lies in the range of Integers ie, ~10^9\n3. Ensure that before calling function to print hexadecimal integer or float number, you must read atleast one headecimal integer or float number respectively otherwise it print any arbitrary number\n");
	printStringUpper("Choose valid number:\n");
		printStringUpper("1. Read Hexadecimal Integer\n2. Print Hexadecimal Integer\n3. Read Float\n4. Print Float\n5. Exit \n");
	while(1)
	{
		printStringUpper("Enter Choice number:\n");
		
		if(readHexInteger(&n)==BAD)
		{
			printStringUpper("Your Choice is incoorect, Please Choose integer in the range [1,5]\n");
		}
		else if(n==1)
		{
			printStringUpper("Enter Hexadecimal Integer: ");
			if(readHexInteger(&hexint)==BAD)
			{
				printStringUpper("Error !! Invalid hexadcimal integer\n");
			}
			else
			{
				printStringUpper("Hexadecimal integer read successfully\n");
			}
		}
		else if(n==2)
		{
			printStringUpper("Previously entered Hexadecimal Integer:  ");
			printHexInteger(hexint);
			printStringUpper("\n");
		}
		else if(n==3)
		{
			printStringUpper("Enter Float: ");
			if(readFloat(&f)==BAD)
			{
				printStringUpper("Error !! Invalid Float\n");
			}
			else
			{
				printStringUpper("Float read successfully\n");
			}
		}
		else if(n==4)
		{
			printStringUpper("Previously entered Float number:  ");
			printFloat(f);
			printStringUpper("\n");
		}
		else if(n==5){break;}
		else
		{
			printStringUpper("Your Choice is incoorect, Please Choose integer in the range [1,5]\n");
		}
		printStringUpper("\n");
	}
}