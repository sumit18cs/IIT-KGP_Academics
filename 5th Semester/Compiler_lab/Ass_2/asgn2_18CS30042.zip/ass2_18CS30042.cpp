//Name : Sumit kumar Yadav
//Roll No.: 18CS30042

#include "toylib.h"
#define MAX 500
#define SYS_READ 0
#define STDIN_FILENO 0


//Function for reading the Hexadecimal Integer
int readHexInteger(int *n)
{
	char buff[MAX];
	int length,i,j,check=0;
	int num,a;
	asm volatile("syscall":"=a"(length) 
		: "0" (SYS_READ), "D" (STDIN_FILENO), "S" (buff), "d" (sizeof(buff))
		: "rcx", "r11", "memory", "cc"
	);
	if(length>9){return BAD;}      //to avoid overflow, so that number lies in range of integers.
	length--;						
	buff[length]=0x0;
	i=length-1;

	while(i>=0 && buff[i]==' '){i--;}   //remove all the spaces that are entered after the given input number
	i--;

	buff[i+2]=0x0;
	length=i+2;
	i=0;

	while(buff[i]==' '){i++;}  //remove all leading spaces.

	if(buff[i]=='-')   //check negative number
	{
		i++;
		check=1;
	}
	if(buff[i]>='0' && buff[i]<='9')   // digit input
	{
		num=buff[i]-'0';
	}
	else if((int)buff[i]>=65 && (int)buff[i]<=70)  //large character input
	{
		num=buff[i]-'A'+10;
	}
	else if((int)buff[i]>=97 && (int)buff[i]<=102) //small character input
	{
		num=buff[i]-'a'+10;
	}
	else{return BAD;}
	j=i+1;
	//make decimal number from given hexadecimal integer
	for(i=j;i<length;i++)
	{
		if(buff[i]>='0' && buff[i]<='9'){a=buff[i]-'0';}
		else if((int)buff[i]>=65 && (int)buff[i]<=70){a=buff[i]-'A'+10;}
		else if((int)buff[i]>=97 && (int)buff[i]<=102){a=buff[i]-'a'+10;}
		else{return BAD;}
		num=num*16+a;
	}
	if(num>10e9){return BAD;}   //to ensure number lies in integer range
	if(check==1){num=(-1)*num;}
	*n=num;
	return GOOD;
}

int printHexInteger(int n)
{
	char buff[MAX],c;
	int digit,length;
	int i=0,j,k;
	if(n==0){buff[i]='0';}
	else
	{
		if(n<0)   //negative number
		{ 
			buff[i]='-';
			i++;
			n=(-1)*n;
		}
		//convert decimal integer into hexadecimal integer number
		while(n)
		{
			digit=n%16;
			n=n/16;
			if(digit<10){buff[i]=(char)('0'+digit);}
			else
			{
				buff[i]=(char)('A'+digit-10);
			}
			i++;
		}

		if(buff[0]=='-'){j=1;}
		else{j=0;}
		k=i-1;
		//reverse the string to get final hexadecimal integer
		while(j<k)   
		{
			c=buff[j];
			buff[j]=buff[k];
			buff[k]=c;
			j++;
			k--;
		}
	}
	buff[i]='\n';
	length=i+1;
	__asm__ __volatile__ (
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(length)
	);
	return i;
}

int readFloat(float *f)
{
	char buff[MAX];
	int length,i,j,p=0,integer=0,check=0;
	float factor=0.1,decimal=0,answer;
	asm volatile("syscall":"=a"(length) 
		: "0" (SYS_READ), "D" (STDIN_FILENO), "S" (buff), "d" (sizeof(buff))
		: "rcx", "r11", "memory", "cc"
	);

	length--;
	buff[length]=0x0;
	i=length-1;

	while(i>=0 && buff[i]==' '){i--;}  //remove all the spaces that are entered after the given input number
	i--;
	buff[i+2]=0x0;
	length=i+2;

	i=0;
	while(buff[i]==' '){i++;} 	 //remove all leading spaces.

	if(buff[i]=='-')
	{
		i++;
		check=1;
	}

	if(buff[i]>='0' && buff[i]<='9')   //for integral part of number
	{
		integer=buff[i]-'0';
	}
	else if(buff[i]=='.')
	{
		p=1;
	}
	else{return BAD;}

	j=i+1;
	for(i=j;i<length;i++)
	{
		if(buff[i]=='.')
		{
			if(p==1){return BAD;}
			else{p=1;}
			continue;
		}
		else if(buff[i]>='0' && buff[i]<='9'){;}
		else{return BAD;}
		if(p==1)
		{
			decimal=decimal+factor*(buff[i]-'0');  //for decimal part
			factor=factor*(0.1);
		}
		else
		{
			integer=integer*10+(buff[i]-'0');
		}
	}
	answer=integer+decimal;
	if(check==1){answer=(-1)*answer;}
	*f=answer;
	return GOOD;
}

int printFloat(float f)
{
	char buff[MAX],buffer[MAX];
	int i=0,tlength=7,length,n;
	int a,digit,k,p,j,c;
	int integer=(int)f;
	f=f-(float)integer;
	if(integer==0 && f<0){buff[i]='-';i++;buff[i]='0';i++;}
	else if(integer==0){buff[i]='0';i++;}
	else
	{
		j=0;
		n=integer;
		if(n<0)    	//negative number
		{
			buffer[j]='-';
			j++;
			n=(-1)*n;
		}
		while(n)	//conversion of integral part
		{
			digit=n%10;
			n=n/10;
			buffer[j]=(char)('0'+digit);
			j++;
		}

		if(buffer[0]=='-'){p=1;}
		else{p=0;}
		a=j-1;
		k=j-1;
		//reverse string to get final integral part of number 
		while(p<k)
		{
			c=buffer[p];
			buffer[p]=buffer[k];
			buffer[k]=c;
			p++;
			k--;
		}
		for(p=0;p<=a;p++){buff[i]=buffer[p];i++;}
	}
	tlength+=a;
	if(f<0){f=(-1)*f;}
	buff[i]='.';
	i++;j=1;
	while(f>0 && j<=6)   //for digits after decimals
	{
		f=f*10;
		n=(int)f;
		buff[i]=n+'0';
		i++;
		f=f-n;
		j++;
	}
	while(j<=6)   //fill all remaining digits with zero
	{
		buff[i]='0';
		i++;j++;
	}
	buff[i]='\n';
	length=i+1;

	__asm__ __volatile__ (
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(length)
	);
	return tlength;
}


int printStringUpper(const char *s)
{
	char buff[MAX];
	int i,length;
	i=0;
	while(s[i]!='\0')   
	{
		int p=(int)s[i];
		if(p>=97 && p<=122){	//lowercase letter
			p=p-32;				//convert into uppercase letter
		}
		buff[i]=(char)p;
		i++;
	}
	//buff[i]='\n';
	length=i;
	__asm__ __volatile__ (
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(length)
	);
	return i;
}