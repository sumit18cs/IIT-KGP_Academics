#ifndef _TOYLIB_H
#define _TOYLIB_H
#define BAD -1
#define GOOD 1
int printStringUpper (const char *);
int printHexInteger (int);
int readHexInteger (int *);
int readFloat (float *);
int printFloat (float);
#endif